Read me !

            " Globe - Terra "  Icon Images

Thank you for downloading this PSD icon image set.

30 icon-files in,
600x600 Photoshop Drawing Image PSD(.psd) files
for your further customization purpose.... : )

Have a fun !    : )

_Resources,_
The Free Globe World Blank Map from here(is in Japanese!),
http://gpscycling.net/fland/map/worldmap.html

All items are free for your customization, But ! For personal use only. Do not redistribute without the author's permission !!

Enjoy !!

taketo.. author

tenoshima@jcom.home.ne.jp
